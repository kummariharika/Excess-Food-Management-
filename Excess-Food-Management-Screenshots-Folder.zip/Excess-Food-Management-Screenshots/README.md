# Excess Food Management – Screenshots

Place your project screenshots in the `screenshots` folder.

Suggested filenames:
- `home-page.png`
- `signup-page.png`
- `login-page.png`
- `forgot-password.png`
- `role-selection.png`
- `donor-dashboard.png`
- `location-map.png`
- `receiver-dashboard.png`

The screenshot images have not been added yet. Upload the original project report or the screenshots to have them extracted and organized here.
